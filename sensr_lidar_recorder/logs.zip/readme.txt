sensr.track_log 검색으로 트랙킹 객체 변동 확인 가능합니다.
